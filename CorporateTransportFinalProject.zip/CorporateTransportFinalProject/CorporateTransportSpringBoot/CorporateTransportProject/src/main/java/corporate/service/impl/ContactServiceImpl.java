package corporate.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import corporate.model.Booking;
import corporate.model.Contact;
import corporate.model.Registration;
import corporate.repo.BookingRepository;
import corporate.repo.ContactRepository;
import corporate.repo.RegistrationRepository;
import corporate.service.BookingService;
import corporate.service.ContactService;
import corporate.service.RegistrationService;

@Service
public class ContactServiceImpl implements ContactService {

	@Autowired
	private ContactRepository repo;
	
	@Override
	public Integer saveContact(Contact s) {
		s = repo.save(s);
		return s.getId();
	}

	@Override
	public void updateContact (Contact s) {
		repo.save(s);
	}
//
	@Override
	public void deleteContact (Integer id) {
		repo.deleteById(id);
	}
//
	@Override
	public Optional<Contact > getOneContact (Integer id) {
		return repo.findById(id);
	}
//
	@Override
	public List<Contact > getAllContact () {
		return repo.findAll();
	}
//
	@Override
	public boolean isContactExist(Integer id) {
		return repo.existsById(id);
	}

}
