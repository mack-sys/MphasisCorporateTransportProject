package corporate.util;

import org.springframework.stereotype.Component;

import corporate.model.Registration;


@Component
public class RegistrationUtil {

	public void mapToActualObject(Registration actual, Registration registration) {
	
		actual.setEmail(registration.getEmail());
		actual.setPassword(registration.getPassword());;
		actual.setConfirmPass(registration.getConfirmPass());
		actual.setTermAndcondition(registration.getTermAndcondition());
		
	}

}
