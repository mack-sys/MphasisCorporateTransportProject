package corporate.repo;



import org.springframework.data.jpa.repository.JpaRepository;

import corporate.model.Feedback;


public interface FeedbackRepository extends JpaRepository<Feedback, Integer>
{

}
