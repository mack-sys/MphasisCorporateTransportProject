package corporate.service;

import java.util.List;
import java.util.Optional;

import corporate.model.Booking;
import corporate.model.Cab;
import corporate.model.Registration;



public interface CabService {

	Integer saveCab(Cab s);
	
//	void updateStudent(Student s);
	
	void deleteCab(Integer id);

	Optional<Cab> getOneCab (Integer id);
	
	List<Cab> getAllCab();

	boolean isCabExist(Integer id);
}
