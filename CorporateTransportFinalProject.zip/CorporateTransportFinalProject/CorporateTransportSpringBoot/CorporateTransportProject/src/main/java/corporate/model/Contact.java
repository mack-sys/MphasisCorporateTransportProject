package corporate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ContactUs")
public class Contact {

	@Id
	@GeneratedValue
	
	private Integer id;
	
	@Column
	private String name;
	
	@Column
	private String email;
	
	@Column
	private String message;
	

	@Column
	private String dateAndtime;
	
	


	public String getDateAndtime() {
		return dateAndtime;
	}

	public void setDateAndtime(String dateAndtime) {
		this.dateAndtime = dateAndtime;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
		

	
	
	
	
	
	
}
//vehicle :any;
//pickup : any;
//pickup_time : any;
//drop :any;
//drop_time :any;
//fullname :any;
//email :any;
//regular : boolean =false;
//pro : boolean = false;
//advance : boolean = false;

////  name: string | undefined;
//contact : number | undefined;
//gender: string | undefined;
//password: string | undefined;
//confirmPass :String | undefined; //