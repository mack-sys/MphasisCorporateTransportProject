package corporate.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import corporate.model.Registration;
import corporate.repo.RegistrationRepository;
import corporate.service.RegistrationService;

@Service
public class RegistrationServiceImpl implements RegistrationService {

	@Autowired
	private RegistrationRepository repo;
	
	@Override
	public Integer saveRegistration(Registration s) {
		s = repo.save(s);
		return s.getId();
	}

//	@Override
//	public void updateStudent(Student s) {
//		repo.save(s);
//	}
//
//	@Override
//	public void deleteStudent(Integer id) {
//		repo.deleteById(id);
//	}
//
//	@Override
//	public Optional<Student> getOneStudent(Integer id) {
//		return repo.findById(id);
//	}
//
	@Override
	public List<Registration> getAllRegistration() {
		return repo.findAll();
	}

	@Override
	public void updateRegistration(Registration s) {
		// TODO Auto-generated method stub
		repo.save(s);
	}

	@Override
	public void deleteRegistration(Integer id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
	}

	@Override
	public Optional<Registration> getOneRegistration(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

	@Override
	public boolean isRegistrationExist(Integer id) {
		// TODO Auto-generated method stub
		return repo.existsById(id);
	}

//	@Override
//	public boolean isStudentExist(Integer id) {
//		return repo.existsById(id);
//	}

}
