package corporate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "Booking")
public class Booking {

	@Id
	@GeneratedValue
	
	private Integer id;
	
	@Column
	private String vehicle;
	@Column
	private String pickup;
	@Column
	private String pickup_time;
	@Column
	private String drop_loc;
	@Column
	private String drop_time;
	@Column
	private String fullname;
	@Column
	private String email;
	@Column
	private String regular;
	@Column
	private String pro;
	@Column
	private String advance;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getVehicle() {
		return vehicle;
	}
	public void setVehicle(String vehicle) {
		this.vehicle = vehicle;
	}
	public String getPickup() {
		return pickup;
	}
	public void setPickup(String pickup) {
		this.pickup = pickup;
	}
	public String getPickup_time() {
		return pickup_time;
	}
	public void setPickup_time(String pickup_time) {
		this.pickup_time = pickup_time;
	}
	public String getDrop() {
		return drop_loc;
	}
	public void setDrop(String drop) {
		this.drop_loc = drop;
	}
	public String getDrop_time() {
		return drop_time;
	}
	public void setDrop_time(String drop_time) {
		this.drop_time = drop_time;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRegular() {
		return regular;
	}
	public void setRegular(String regular) {
		this.regular = regular;
	}
	public String getPro() {
		return pro;
	}
	public void setPro(String pro) {
		this.pro = pro;
	}
	public String getAdvance() {
		return advance;
	}
	public void setAdvance(String advance) {
		this.advance = advance;
	}
	
	
	
	
}
//vehicle :any;
//pickup : any;
//pickup_time : any;
//drop :any;
//drop_time :any;
//fullname :any;
//email :any;
//regular : boolean =false;
//pro : boolean = false;
//advance : boolean = false;

////  name: string | undefined;
//contact : number | undefined;
//gender: string | undefined;
//password: string | undefined;
//confirmPass :String | undefined; //