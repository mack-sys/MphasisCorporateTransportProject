package corporate.service;

import java.util.List;
import java.util.Optional;

import corporate.model.Registration;



public interface RegistrationService {

	Integer saveRegistration(Registration s);
	void updateRegistration(Registration s);
//	
	void deleteRegistration(Integer id);
//
	Optional<Registration> getOneRegistration(Integer id);
	List<Registration> getAllRegistration();
//
	boolean isRegistrationExist(Integer id);
}
