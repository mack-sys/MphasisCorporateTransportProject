package corporate.service;

import java.util.List;
import java.util.Optional;

import corporate.model.Booking;
import corporate.model.Registration;



public interface BookingService {

	Integer saveBooking(Booking s);
//	void updateStudent(Student s);
	
	void deleteBooking(Integer id);

	Optional<Booking> getOneBooking (Integer id);
	
	List<Booking> getAllBooking();

	boolean isBookingExist(Integer id);
}
