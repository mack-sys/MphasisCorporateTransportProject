package corporate.service.impl;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import corporate.model.Feedback;
import corporate.repo.FeedbackRepository;
import corporate.service.FeedbackService;

@Service
public class FeedbackServiceImpl implements FeedbackService{

	@Autowired
	private FeedbackRepository repo;
	
	@Override
	public Integer saveFeedback(Feedback s) {
		// TODO Auto-generated method stub
		s = repo.save(s);
		return s.getId();
	}

	@Override
	public void deleteFeedback(Integer id) {
		repo.deleteById(id);
		
	}

	@Override
	public Optional<Feedback> getOneFeedback(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

	@Override
	public List<Feedback> getAllFeedback() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public boolean isFeedbackExist(Integer id) {
		// TODO Auto-generated method stub
		return repo.existsById(id);
	}
	

    	
}
