package corporate.service;

import java.util.List;
import java.util.Optional;

import corporate.model.Booking;
import corporate.model.Contact;
import corporate.model.Registration;



public interface ContactService {

	Integer saveContact(Contact s);
	void updateContact(Contact s);
	
	void deleteContact(Integer id);

	Optional<Contact> getOneContact(Integer id);
	List<Contact> getAllContact();

	boolean isContactExist(Integer id);
}
