package corporate.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import corporate.model.Booking;
import corporate.model.Contact;
import corporate.model.Registration;



public interface ContactRepository extends JpaRepository<Contact, Integer>
{

}
