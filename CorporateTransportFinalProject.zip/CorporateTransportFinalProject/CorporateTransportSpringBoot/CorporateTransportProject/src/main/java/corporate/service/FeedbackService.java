package corporate.service;

import java.util.List;
import java.util.Optional;

import corporate.model.Booking;
import corporate.model.Feedback;
import corporate.model.Registration;



public interface FeedbackService {

	Integer saveFeedback(Feedback s);
//	void updateStudent(Student s);
	
	void deleteFeedback(Integer id);

	Optional<Feedback> getOneFeedback(Integer id);
	List<Feedback> getAllFeedback();

	boolean isFeedbackExist(Integer id);
}
