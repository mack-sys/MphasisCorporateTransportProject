package corporate.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Entity
@Table(name = "Feedback1")
public class Feedback {
	@Id
	@GeneratedValue

	private Integer id;
	
	@Column
	private String name;
	@Column
	private String email;
	
	@Column
	private Integer starRating;
	
	@Column
 private String ontimepickup;
	
	@Column 
 private String protocol;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getStarRating() {
		return starRating;
	}
	public void setStarRating(Integer starRating) {
		this.starRating = starRating;
	}
	public String getOntimepickup() {
		return ontimepickup;
	}
	public void setOntimepickup(String ontimepickup) {
		this.ontimepickup = ontimepickup;
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	
	public Feedback()
	{
		
	}
	
	public Feedback(Integer id, String name, String email, Integer starRating, String ontimepickup, String protocol) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.starRating = starRating;
		this.ontimepickup = ontimepickup;
		this.protocol = protocol;
	}
	
	
	
	
	
}
