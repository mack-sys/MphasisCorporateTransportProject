package corporate.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import corporate.model.Cab;


import corporate.repo.CabRepository;

import corporate.service.CabService;


@Service
public class CabServiceImpl implements CabService {

	@Autowired
	private CabRepository repo;
	
	@Override
	public Integer saveCab(Cab s) {
		s = repo.save(s);
		return s.getId();
	}

	@Override
	public void deleteCab(Integer id) {
		repo.deleteById(id);
		
	}

	@Override
	public Optional<Cab> getOneCab(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

	@Override
	public List<Cab> getAllCab() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public boolean isCabExist(Integer id) {
		// TODO Auto-generated method stub
		return repo.existsById(id);
	}

//	@Override
//	public void updateStudent(Student s) {
//		repo.save(s);
//	}
//
//	@Override
//	public void deleteStudent(Integer id) {
//		repo.deleteById(id);
//	}
//
//	@Override
//	public Optional<Student> getOneStudent(Integer id) {
//		return repo.findById(id);
//	}
//
//	@Override
//	public List<Student> getAllStudents() {
//		return repo.findAll();
//	}
//
//	@Override
//	public boolean isStudentExist(Integer id) {
//		return repo.existsById(id);
//	}

}
