package corporate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "Cab")
public class Cab {

	@Id
	@GeneratedValue
	
	private Integer id;
	
	@Column
	private String pick;
	@Column
	private String droploc;
	@Column
	private String dateof;
	@Column
	private String timeof;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getPick() {
		return pick;
	}


	public void setPick(String pick) {
		this.pick = pick;
	}


	public String getDroplocation() {
		return droploc;
	}


	public void setDroplocation(String droplocation) {
		this.droploc = droplocation;
	}


	public String getPickdate() {
		return dateof;
	}


	public void setPickdate(String pickdate) {
		this.dateof = pickdate;
	}


	public String getPicktime() {
		return timeof;
	}


	public void setPicktime(String picktime) {
		this.timeof = picktime;
	}
	
	



	
	
	
	
	
	
}
//vehicle :any;
//pickup : any;
//pickup_time : any;
//drop :any;
//drop_time :any;
//fullname :any;
//email :any;
//regular : boolean =false;
//pro : boolean = false;
//advance : boolean = false;

////  name: string | undefined;
//contact : number | undefined;
//gender: string | undefined;
//password: string | undefined;
//confirmPass :String | undefined; //