package corporate.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import corporate.model.Registration;



public interface RegistrationRepository extends JpaRepository<Registration, Integer>
{

}
