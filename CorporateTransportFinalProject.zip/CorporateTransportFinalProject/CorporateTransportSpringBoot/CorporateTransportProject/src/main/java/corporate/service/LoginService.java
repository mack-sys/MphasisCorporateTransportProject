package corporate.service;

import java.util.List;
import java.util.Optional;

import corporate.model.Registration;



public interface LoginService {

//	public void saveLogin();
//	void updateStudent(Student s);
//	
//	void deleteStudent(Integer id);
//
//	Optional<Student> getOneStudent(Integer id);
	
	List<Registration> getAllRegistration();
//
//	boolean isStudentExist(Integer id);
}
