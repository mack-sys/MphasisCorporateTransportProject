package corporate.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import corporate.model.Booking;
import corporate.model.Registration;



public interface BookingRepository extends JpaRepository<Booking, Integer>
{

}
