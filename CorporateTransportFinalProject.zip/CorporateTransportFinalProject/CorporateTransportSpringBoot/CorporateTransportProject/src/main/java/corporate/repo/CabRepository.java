package corporate.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import corporate.model.Booking;
import corporate.model.Cab;
import corporate.model.Registration;



public interface CabRepository extends JpaRepository<Cab, Integer>
{

}
