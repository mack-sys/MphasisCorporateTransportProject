package corporate.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import corporate.model.Registration;
import corporate.repo.RegistrationRepository;
import corporate.service.LoginService;
import corporate.service.RegistrationService;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private RegistrationRepository repo;



	@Override
	public List<Registration> getAllRegistration() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}


	


//	@Override
//	public void updateStudent(Student s) {
//		repo.save(s);
//	}
//
//	@Override
//	public void deleteStudent(Integer id) {
//		repo.deleteById(id);
//	}
//
//	@Override
//	public Optional<Student> getOneStudent(Integer id) {
//		return repo.findById(id);
//	}
//
//	@Override
//	public List<Student> getAllStudents() {
//		return repo.findAll();
//	}
//
//	@Override
//	public boolean isStudentExist(Integer id) {
//		return repo.existsById(id);
//	}

}
