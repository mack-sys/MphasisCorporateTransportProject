import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserRegistration } from '../Model/user-registration';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-update-registration',
  templateUrl: './update-registration.component.html',
  styleUrls: ['./update-registration.component.css']
})
export class UpdateRegistrationComponent implements OnInit {

  id: number | any;
  registration: UserRegistration | any;

  // inject service and acivated Route param
  constructor(private service: UserRegistrationService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    // read id sent by all component as /edit/id
    // tslint:disable-next-line: no-string-literal
    this.id = this.activatedRoute.snapshot.params['id'];
    // make service call to get student object
    this.service.getOneRegistration(this.id).subscribe(
      data => {
      this.registration = data;
      console.log(this.registration);
    }, error => {
      console.log(error);
    });
  }

  // tslint:disable-next-line: typedef
  updateRegistration() {
    this.service.updateRegistration(this.id, this.registration)
    .subscribe( data => {
      console.log(data);
      this.router.navigate(['viewRegistration']);
    });
  }
}
