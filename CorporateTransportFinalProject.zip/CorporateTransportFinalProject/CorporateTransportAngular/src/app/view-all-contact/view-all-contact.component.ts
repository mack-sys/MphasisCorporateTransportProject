import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Contact } from '../Model/contact';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-view-all-contact',
  templateUrl: './view-all-contact.component.html',
  styleUrls: ['./view-all-contact.component.css']
})
export class ViewAllContactComponent implements OnInit {

  contact: Contact[] | any;
  message: string | any;
  // inject service layer
  constructor(private service:  UserRegistrationService, private router: Router) { }

  // on page load call this method
  ngOnInit(): void {
    this.getAllContact();
  }
  // fetch data from backend application using service
  // tslint:disable-next-line: typedef
  getAllContact() {
    return this.service.getAllContact()
    .subscribe(
      data => {
        this.contact = data;
      }, error => {
        console.log(error);
      }
    );
  }

  // tslint:disable-next-line: typedef
  deleteContact(id: number) {
    if (confirm('Do you want to delete?')) {
      this.service.deleteOneContact(id).subscribe(data => {
        this.message = data;
        this.getAllContact();
      }, error => {
        console.log(error);
      });
    } else {
      this.message = '';
    }
  }

  // tslint:disable-next-line: typedef
  editRegistration(id: number) {
    this.router.navigate(['editRegistration', id]);
  }


}
