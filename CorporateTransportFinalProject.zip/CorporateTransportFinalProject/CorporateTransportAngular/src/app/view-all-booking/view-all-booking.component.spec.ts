import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllBookingComponent } from './view-all-booking.component';

describe('ViewAllBookingComponent', () => {
  let component: ViewAllBookingComponent;
  let fixture: ComponentFixture<ViewAllBookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllBookingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
