import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Booking } from '../Model/booking';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-view-all-booking',
  templateUrl: './view-all-booking.component.html',
  styleUrls: ['./view-all-booking.component.css']
})
export class ViewAllBookingComponent implements OnInit {

  booking:Booking[] | any;
  message: string | any;
  // inject service layer
  constructor(private service:  UserRegistrationService, private router: Router) { }

  // on page load call this method
  ngOnInit(): void {
    this.getAllBooking();
  }
  // fetch data from backend application using service
  // tslint:disable-next-line: typedef
  getAllBooking() {
    return this.service.getAllBooking()
    .subscribe(
      data => {
        this.booking = data;
      }, error => {
        console.log(error);
      }
    );
  }

  // tslint:disable-next-line: typedef
  deleteBooking(id: number) {
    if (confirm('Do you want to delete?')) {
      this.service.deleteOneBooking(id).subscribe(data => {
        this.message = data;
        this.getAllBooking();
   
      }, error => {
        console.log(error);
      });
    } else {
      this.message = '';
    }
  }

  // tslint:disable-next-line: typedef
  editRegistration(id: number) {
    this.router.navigate(['editRegistration', id]);
  }
}
