import { Component, OnInit } from '@angular/core';
import { Cab } from '../Model/cab';

import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-pickup-drop',
  templateUrl: './pickup-drop.component.html',
  styleUrls: ['./pickup-drop.component.css']
})
export class PickupDropComponent implements OnInit {

  // form backing object
  cab:Cab | any;
  // message to ui
  message: string | any;

  // inject service class
  constructor(private service: UserRegistrationService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.cab = new Cab();
 
  }

  // tslint:disable-next-line: typedef

  createCab() {
    console.log(this.cab);
    
    this.service.createCab(this.cab)
    .subscribe(data => {
      this.message = data; // read message
      this.cab= new Cab(); // clear form
    }, error => {
      console.log(error);
    });
  }
 


}
