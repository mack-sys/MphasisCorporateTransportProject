import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserRegistration } from '../Model/user-registration';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-view-all-registration',
  templateUrl: './view-all-registration.component.html',
  styleUrls: ['./view-all-registration.component.css']
})
export class ViewAllRegistrationComponent implements OnInit {

  registration: UserRegistration[] | any;
  message: string | any;
  // inject service layer
  constructor(private service:  UserRegistrationService, private router: Router) { }

  // on page load call this method
  ngOnInit(): void {
    this.getAllRegistration();
  }
  // fetch data from backend application using service
  // tslint:disable-next-line: typedef
  getAllRegistration() {
    return this.service.getAllRegistration()
    .subscribe(
      data => {
        this.registration = data;
      }, error => {
        console.log(error);
      }
    );
  }

  // tslint:disable-next-line: typedef
  deleteRegistration(id: number) {
    if (confirm('Do you want to delete?')) {
      this.service.deleteOneRegistration(id).subscribe(data => {
        this.message = data;
        this.getAllRegistration();
      }, error => {
        console.log(error);
      });
    } else {
      this.message = '';
    }
  }

  // tslint:disable-next-line: typedef
  editRegistration(id: number) {
    this.router.navigate(['editRegistration', id]);
  }

}
