import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllRegistrationComponent } from './view-all-registration.component';

describe('ViewAllRegistrationComponent', () => {
  let component: ViewAllRegistrationComponent;
  let fixture: ComponentFixture<ViewAllRegistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllRegistrationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
