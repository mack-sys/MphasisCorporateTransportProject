import { Component, OnInit } from '@angular/core';
import { UserRegistration } from '../Model/user-registration';
import { UserRegistrationService } from '../user-registration.service';



@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
   // form backing object
   registration1: UserRegistration | any;
   // message to ui
   message: string | any;
 
   // inject service class
   constructor(private service: UserRegistrationService) { }
 
   ngOnInit(): void {
     // when page is loaded clear form data
     this.registration1 = new UserRegistration();
  
   }
 
   // tslint:disable-next-line: typedef
 
   createRegistration() {
     this.service.createRegistration(this.registration1)
     .subscribe(data => {
       this.message = data; // read message
       this.registration1 = new UserRegistration(); // clear form
     }, error => {
       console.log(error);
     });
   }
}
