import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Booking } from './Model/booking';
import { Cab } from './Model/cab';
import { Contact } from './Model/contact';




import { Feedback } from './Model/feedback';
import { Login } from './Model/login';
import { UserRegistration } from './Model/user-registration';

@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {

  private basePath = 'http://localhost:8090/rest/student';



  constructor(private http: HttpClient) { }

  createRegistration(registration: UserRegistration): Observable<Object> {
    return this.http.post(`${this.basePath}/save`, registration, {responseType: 'text'});
  }

  createBooking(booking: Booking): Observable<Object> {
 return this.http.post(`${this.basePath}/booking`, booking, {responseType: 'text'});
  }

  createContact(contact: Contact): Observable<Object> {
    return this.http.post(`${this.basePath}/contact`, contact, {responseType: 'text'});
     }
     createFeedback(feedback: Feedback): Observable<Object> {
      return this.http.post(`${this.basePath}/feedback`, feedback, {responseType: 'text'});
    }
     createCab(cab: Cab): Observable<Object> {
      return this.http.post(`${this.basePath}/cab1`, cab, {responseType: 'text'});
    }
  
  

  getAllRegistration(): Observable<UserRegistration[]> {
    return this.http.get<UserRegistration[]>(`${this.basePath}/allregistration`);
  }
  getAllFeedback(): Observable<Feedback[]> {
    return this.http.get<Feedback[]>(`${this.basePath}/allfeedback`);
  }
  getAllBooking(): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.basePath}/allbooking`);
  }
  getAllContact(): Observable<Contact[]> {
    return this.http.get<Contact[]>(`${this.basePath}/allContact`);
  }
  getAllCab(): Observable<Cab[]> {
    return this.http.get<Cab[]>(`${this.basePath}/allCab`);
  }

  deleteOneRegistration(id: number): Observable<any> {
    return this.http.delete(`${this.basePath}/remove/${id}`, {responseType: 'text'});
  }
  deleteOneFeedback(id: number): Observable<any> {
    return this.http.delete(`${this.basePath}/removeFeedback/${id}`, {responseType: 'text'});
  }
  deleteOneBooking(id: number): Observable<any> {
    return this.http.delete(`${this.basePath}/removeBooking/${id}`, {responseType: 'text'});
  }
  deleteOneContact(id: number): Observable<any> {
    return this.http.delete(`${this.basePath}/removeContact/${id}`, {responseType: 'text'});
  }
  deleteOneCab(id: number): Observable<any> {
    return this.http.delete(`${this.basePath}/removeCab/${id}`, {responseType: 'text'});
  }
  
  updateRegistration(id: number, registration: UserRegistration): Observable<any> {
    return this.http.put(`${this.basePath}/modifyRegistration/${id}`, registration, {responseType : 'text'});
  }
  getOneRegistration(id: number): Observable<UserRegistration> {
    return this.http.get<UserRegistration>(`${this.basePath}/one/${id}`);
  }

  getOneFeedback(id: number): Observable<Feedback> {
    return this.http.get<Feedback>(`${this.basePath}/oneFeedback/${id}`);
  }
  getOneBooking(id: number): Observable<Booking> {
    return this.http.get<Booking>(`${this.basePath}/oneBooking/${id}`);
  }
  getOneContact(id: number): Observable<Contact> {
    return this.http.get<Contact>(`${this.basePath}/oneContact/${id}`);
  }
  getOneCab(id: number): Observable<Cab> {
    return this.http.get<Cab>(`${this.basePath}/oneCab/${id}`);
  }




  // getFeedbackList():Observable<Feedback[]>
  // {
  //   return this.http.get<Feedback[]>(`${this.basePath}/feedbacks`);
  // }
  
  // public createFeedback(feedback: Feedback):Observable<Object>{
  //   return this.http.post(`${this.basePath}/save`,feedback);
  // }

  // public createPickupdrop(pickupdrop:Pickupdrop):Observable<Object>
  // {
  //   return this.http.post(`${this.basePath}/create`,pickupdrop);
  // }

  // getFeedbackById(id:number): Observable<Feedback>{
  //  return this.http.get<Feedback>(`${this.basePath}/update/${id}`);
  // }


  // updateFeedback(id:number,feedback:Feedback):Observable<Object>
  // {
  //   return this.http.put(`${this.basePath}/update/${id}`,feedback);
  // }

  // deleteFeedback(id:number):Observable<Object>{
  //   return this.http.delete(`${this.basePath}/delete/${id}`);
  // }

}
