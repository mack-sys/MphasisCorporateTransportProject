import { Component, OnInit } from '@angular/core';
import { Contact } from '../Model/contact';

import { UserRegistrationService } from '../user-registration.service';
// import {Contact} from '../contact';
// import {ContactService} from '../contact.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {
    // form backing object
    contact: Contact | any;
    // message to ui
    message: string | any;
  

   
     // inject service class
     constructor(private service: UserRegistrationService) { }
   
     ngOnInit(): void {
       // when page is loaded clear form data
       this.contact= new Contact();
    
     }
   
     // tslint:disable-next-line: typedef
   
     createContactUs() {
       this.service.createContact(this.contact)
       .subscribe(data => {
         this.message = data; // read message
         this.contact = new Contact(); // clear form
       }, error => {
         console.log(error);
       });
     }
}
