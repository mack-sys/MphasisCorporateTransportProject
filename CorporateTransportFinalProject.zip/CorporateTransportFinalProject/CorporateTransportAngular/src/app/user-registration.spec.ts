import { UserRegistration } from './Model/user-registration';

describe('UserRegistration', () => {
  it('should create an instance', () => {
    expect(new UserRegistration()).toBeTruthy();
  });
});
