import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from '../Model/feedback';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-view-all-feedback',
  templateUrl: './view-all-feedback.component.html',
  styleUrls: ['./view-all-feedback.component.css']
})
export class ViewAllFeedbackComponent implements OnInit {

  feedback: Feedback[] | any;
  message: string | any;
  // inject service layer
  constructor(private service:  UserRegistrationService, private router: Router) { }

  // on page load call this method
  ngOnInit(): void {
    this.getAllFeedback();
  }
  // fetch data from backend application using service
  // tslint:disable-next-line: typedef
  getAllFeedback() {
    return this.service.getAllFeedback()
    .subscribe(
      data => {
        this.feedback = data;
      }, error => {
        console.log(error);
      }
    );
  }

  // tslint:disable-next-line: typedef
  deleteFeedback(id: number) {
    if (confirm('Do you want to delete?')) {
      this.service.deleteOneFeedback(id).subscribe(data => {
        this.message = data;
        this.getAllFeedback();
      }, error => {
        console.log(error);
      });
    } else {
      this.message = '';
    }
  }

  // tslint:disable-next-line: typedef
  editRegistration(id: number) {
    this.router.navigate(['editRegistration', id]);
  }

}
