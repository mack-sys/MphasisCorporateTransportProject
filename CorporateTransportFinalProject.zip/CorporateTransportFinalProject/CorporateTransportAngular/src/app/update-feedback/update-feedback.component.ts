import { Component, OnInit } from '@angular/core';
import { ActivatedRoute ,Router} from '@angular/router';
import { Feedback } from '../feedback';
import { FeedbackService } from '../feedback.service';

@Component({
  selector: 'app-update-feedback',
  templateUrl: './update-feedback.component.html',
  styleUrls: ['./update-feedback.component.css']
})
export class UpdateFeedbackComponent implements OnInit {
  id:number;
  feedback: Feedback=new Feedback(); 
  constructor(private feedbackService:FeedbackService,
    private route:ActivatedRoute,
    private router:Router){}

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id'];
    this.feedbackService.getFeedbackById(this.id).subscribe(data=>{
      this.feedback=data;    },
      error=>console.log(error));
  }
 onSubmit()
 { 
   this.feedbackService.updateFeedback(this.id,this.feedback).subscribe(
     data=>{ this.gotToFeedbackList();
    },
    error=>console.log(error)
   );
 }

 gotToFeedbackList()
 {
   this.router.navigate(['/admin'])
 }
}
