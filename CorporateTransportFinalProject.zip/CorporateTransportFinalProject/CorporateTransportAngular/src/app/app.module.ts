import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { PickupDropComponent } from './pickup-drop/pickup-drop.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BookingComponent } from './booking/booking.component';
import { AboutComponent } from './about/about.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { PracticeComponent } from './practice/practice.component';
import { HttpClientModule } from '@angular/common/http';
import { AdminComponent } from './admin/admin.component';
import { ViewAllRegistrationComponent } from './view-all-registration/view-all-registration.component';
import { ViewAllBookingComponent } from './view-all-booking/view-all-booking.component';
import { ViewAllContactComponent } from './view-all-contact/view-all-contact.component';
import { ViewAllFeedbackComponent } from './view-all-feedback/view-all-feedback.component';
import { UpdateRegistrationComponent } from './update-registration/update-registration.component';
import { NgxStarRatingModule } from 'ngx-star-rating';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    PickupDropComponent,
    BookingComponent,
    AboutComponent,
    ContactUsComponent,
    PracticeComponent,
    AdminComponent,
    ViewAllRegistrationComponent,
    ViewAllBookingComponent,
    ViewAllContactComponent,
    ViewAllFeedbackComponent,
    UpdateRegistrationComponent,
    FeedbackComponent
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
    
    
    

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
