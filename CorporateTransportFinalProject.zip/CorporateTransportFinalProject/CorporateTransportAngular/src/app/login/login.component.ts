import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../Model/login';
import { UserRegistration } from '../Model/user-registration';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  registration: UserRegistration[] | any;
  message: string | any;
  txt : any;
  login : Login | any;
  // inject service layer
  constructor(private service:  UserRegistrationService, private router: Router) { }

  // on page load call this method
  ngOnInit(): void {
    this.getAllRegistration();
    this.login = new Login();
   
  
  }
  
  // fetch data from backend application using service
  // tslint:disable-next-line: typedef
  loginCheck(){
    for(let x of  this.registration){
      console.log(x);
      
        if(x.password === this.login.password){
          console.log("login");
          console.log(x.email);
          this.router.navigate(['admin']);
          
          
        }else{
          console.log("wrong");
          console.log(this.login);
          this.txt ="Wrong Password"
          
          
        }
      
    }
  }
  getAllRegistration() {
 
    return this.service.getAllRegistration()
    .subscribe(
      data => {

        
        this.registration = data;
      
      }, error => {
        console.log(error);
      }
    );
  }

  // tslint:disable-next-line: typedef
  deleteRegistration(id: number) {
    if (confirm('Do you want to delete?')) {
      this.service.deleteOneRegistration(id).subscribe(data => {
        this.message = data;
        this.getAllRegistration();
      }, error => {
        console.log(error);
      });
    } else {
      this.message = '';
    }
  }

  // tslint:disable-next-line: typedef
  editRegistration(id: number) {
    this.router.navigate(['editRegistration', id]);
  }

}
