export class Login {
    
  
    email : string | undefined;
    password : any;
  
    

}
