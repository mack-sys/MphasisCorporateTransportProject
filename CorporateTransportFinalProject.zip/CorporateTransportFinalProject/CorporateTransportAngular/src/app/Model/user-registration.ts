export class UserRegistration {
    
  
    email : any;
    password : any;
    confirmPass: any;
    termAndcondition : boolean =false;
    urname : any;
    contact :any;
    

}
