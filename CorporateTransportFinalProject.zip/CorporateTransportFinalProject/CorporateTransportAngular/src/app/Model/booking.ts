

export class Booking{
    vehicle :any;
    pickup : any;
    pickup_time : any;
    drop :any;
    drop_time :any;
    fullname :any;
    email :any;
    regular : boolean =false;
    pro : boolean = false;
    advance : boolean = false;

}