export class Contact{
        name : any;
        email :any;
        message : any;
        dateAndtime : any;
}