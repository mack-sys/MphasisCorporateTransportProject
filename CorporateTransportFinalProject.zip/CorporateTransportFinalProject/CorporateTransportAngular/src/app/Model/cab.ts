export class Cab{
  pick :any;
  droploc:any;
  dateof:any;
  timeof:any;
} 