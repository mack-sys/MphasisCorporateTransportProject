export class Feedback {
    id:number | any;
    name:String | any;
    email:String | any;
    starRating:number | any;
    ontimepickup:Boolean=false;
    protocol:Boolean=false;
}

