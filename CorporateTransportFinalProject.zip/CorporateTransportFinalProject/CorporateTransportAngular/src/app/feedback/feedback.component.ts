import { Component, OnInit } from '@angular/core';
import { Feedback } from '../Model/feedback';

import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
   // form backing object
   feedback: Feedback | any;
   // message to ui
   message: string | any;
 
   // inject service class
   constructor(private service: UserRegistrationService) { }
 
   ngOnInit(): void {
     // when page is loaded clear form data
     this.feedback = new Feedback();
  
   }
 
   // tslint:disable-next-line: typedef
 
   onSubmit() {
     this.service.createFeedback(this.feedback)
     .subscribe(data => {
       this.message = data; // read message
       this.feedback = new Feedback(); // clear form
     }, error => {
       console.log(error);
     });
   }


}





