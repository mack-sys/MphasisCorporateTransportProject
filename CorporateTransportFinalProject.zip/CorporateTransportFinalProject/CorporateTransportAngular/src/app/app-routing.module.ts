import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdminComponent } from './admin/admin.component';
import { BookingComponent } from './booking/booking.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { LoginComponent } from './login/login.component';
import { PickupDropComponent } from './pickup-drop/pickup-drop.component';
import { RegistrationComponent } from './registration/registration.component';
import { UpdateRegistrationComponent } from './update-registration/update-registration.component';
import { ViewAllBookingComponent } from './view-all-booking/view-all-booking.component';
import { ViewAllContactComponent } from './view-all-contact/view-all-contact.component';
import { ViewAllFeedbackComponent } from './view-all-feedback/view-all-feedback.component';
import { ViewAllRegistrationComponent } from './view-all-registration/view-all-registration.component';

const routes: Routes = [ 
  { path: '', component: PickupDropComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'login', component:LoginComponent  },
  { path: 'booking', component: BookingComponent },
  { path: 'about', component: AboutComponent },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'feedback', component: FeedbackComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'viewRegistration', component: ViewAllRegistrationComponent},
  { path: 'viewBooking', component: ViewAllBookingComponent},
  { path: 'viewContact', component: ViewAllContactComponent},
  { path: 'viewFeedback', component: ViewAllFeedbackComponent},
  {path: 'editRegistration/:id', component: UpdateRegistrationComponent}
  ];
  

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
