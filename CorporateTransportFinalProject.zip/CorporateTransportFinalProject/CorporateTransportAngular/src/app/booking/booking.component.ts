import { Component, OnInit } from '@angular/core';
import { Booking } from '../Model/booking';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

    // form backing object
    booking: Booking | any;
    // message to ui
    message: string | any;
  
    // inject service class
    constructor(private service: UserRegistrationService) { }
  
    ngOnInit(): void {
      // when page is loaded clear form data
      this.booking = new Booking();
   
    }
  
    // tslint:disable-next-line: typedef
  
    createBooking() {
     console.log("submit");
     
      
      this.service.createBooking(this.booking)
      .subscribe(data => {
        this.message = data; // read message
        this.booking = new Booking(); // clear form
      }, error => {
        console.log(error);
      });
    }


}
